package com.example.tarea3_zb_carlos.fragments.bikes;

import static com.example.tarea3_zb_carlos.fragments.bikes.bikesFragment.*;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.tarea3_zb_carlos.BikeContent;
import com.example.tarea3_zb_carlos.MainActivity;
import com.example.tarea3_zb_carlos.R;
import com.example.tarea3_zb_carlos.databinding.FragmentBikesBinding;
import com.example.tarea3_zb_carlos.databinding.FragmentDateBinding;
import com.example.tarea3_zb_carlos.fragments.bikes.recycler_view.MyAdapter;

import java.util.List;


public class bikesFragment extends Fragment implements MyAdapter.EnviarCorreo {


    RecyclerView rcv;
    RecyclerView.LayoutManager layout_manager;
    RecyclerView.Adapter myAdapter;
    FragmentBikesBinding binding;
    MyAdapter.EnviarCorreo env;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        BikeContent.clearBikes();
        BikeContent.loadBikesFromJSON(getContext());

        binding = FragmentBikesBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        rcv = root.findViewById(R.id.rcv_bikes);
        layout_manager = new LinearLayoutManager(getContext());
        rcv.setLayoutManager(layout_manager);


        rcv.setAdapter(new MyAdapter(BikeContent.ITEMS, this));

        return root;
    }


    @Override
    public void enviar(String email) {
        boolean isIntentSafe = false;
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        PackageManager packageManager = getContext().getPackageManager();
        List<ResolveInfo> activities;
        intent.setData(Uri.parse("mailto:"));

       String to[] = {email};
        intent.putExtra(Intent.EXTRA_EMAIL, to);
        intent.putExtra(Intent.EXTRA_SUBJECT, "Alquiler de bicicleta");
        intent.putExtra(Intent.EXTRA_TEXT, "¡Hola! Encantado de saludarte. \n\n Me gustaría alquilar tu maravillosa bicicleta para el dia "+ MainActivity.FECHA+". \n\n Un saludo.");

        intent.setType("message/rfc822");

        intent.createChooser(intent, "Enviar email");

        activities = packageManager.queryIntentActivities(intent,
                PackageManager.MATCH_DEFAULT_ONLY);
        isIntentSafe = activities.size() > 0;

        if (MainActivity.FECHA != null) {
            if (isIntentSafe){
                Toast.makeText(getContext(), "¡Enviando un email!", Toast.LENGTH_LONG).show();
                startActivity(intent);
            } else {
                Toast.makeText(getContext(), "¡No dispondes de una app para enviar un email!", Toast.LENGTH_LONG).show();
            }
        }else{
            Toast.makeText(getContext(), "¡Tienes que seleccionar antes una fecha!", Toast.LENGTH_LONG).show();
        }
    }




}