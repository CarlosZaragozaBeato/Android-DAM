package com.example.tarea3_zb_carlos.fragments.date;


import android.app.DatePickerDialog;
import androidx.fragment.app.DialogFragment;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class DatePicker extends DialogFragment{


    fecha_seleccionada f;
    dateFragment ctx;

    public DatePicker(dateFragment ctx){
        this.ctx = ctx;
        f= ctx;
    }

    public interface fecha_seleccionada{
        public void onResultadoFecha(GregorianCalendar fecha);
    }



    public void obtenerFecha(){
        Calendar c = Calendar.getInstance();
        final int mes = c.get(Calendar.MONTH);
        final int dia = c.get(Calendar.DAY_OF_MONTH);
        final int anio = c.get(Calendar.YEAR);

        DatePickerDialog recogerFecha = new DatePickerDialog(ctx.getContext(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(android.widget.DatePicker datePicker, int year, int month, int dayOfMonth) {
                GregorianCalendar g=new GregorianCalendar(year,month,dayOfMonth);
                f.onResultadoFecha(g);
            }
        },anio, mes, dia);
        recogerFecha.show();
    }



}