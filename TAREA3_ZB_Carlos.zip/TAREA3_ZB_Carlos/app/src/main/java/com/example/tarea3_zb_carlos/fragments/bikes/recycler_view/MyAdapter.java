package com.example.tarea3_zb_carlos.fragments.bikes.recycler_view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tarea3_zb_carlos.BikeContent;
import com.example.tarea3_zb_carlos.R;
import com.example.tarea3_zb_carlos.fragments.bikes.bikesFragment;;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>  {

    ArrayList<BikeContent.Bike> data_model = new ArrayList();
    EnviarCorreo env;

    public interface EnviarCorreo{
        public void enviar(String email);
    }


    public MyAdapter(ArrayList<BikeContent.Bike> data_model, bikesFragment env){
        this.data_model = data_model;
        this.env =  env;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_view_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        String description = data_model.get(position).getOwner()+"\n"+data_model.get(position).getLocation()+"\n"+data_model.get(position).getDescription();

        holder.getTitle().setText(data_model.get(position).getCity());
        holder.getDescription().setText(description);
        holder.getImage().setImageBitmap(data_model.get(position).getPhoto());
        holder.getImageButton().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                env.enviar(data_model.get(position).getEmail());
            }
        });
    }

    @Override
    public int getItemCount() {
        return data_model.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private final ImageView img;
        private final TextView tv1;
        private final TextView tv2;
        private final ImageButton ibtn_enviar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.img = itemView.findViewById(R.id.iv_bike);
            this.tv1 = itemView.findViewById(R.id.tv_title);
            this.tv2 = itemView.findViewById(R.id.tv_description);
            this.ibtn_enviar = itemView.findViewById(R.id.ibtn_enviar);
        }
        public TextView getTitle(){return tv1;}
        public TextView getDescription(){return tv2;}
        public ImageView getImage(){return img;}
        public ImageButton getImageButton(){return ibtn_enviar;}
    }
}
