package com.example.tarea3_zb_carlos.fragments.date;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.tarea3_zb_carlos.MainActivity;
import com.example.tarea3_zb_carlos.R;
import com.example.tarea3_zb_carlos.databinding.FragmentDateBinding;
import com.example.tarea3_zb_carlos.databinding.FragmentHomeBinding;

import java.util.Calendar;
import java.util.GregorianCalendar;


public class dateFragment extends Fragment implements DatePicker.fecha_seleccionada, View.OnClickListener {

    DatePicker date_picker;
    FragmentDateBinding binding;
    Button resultado;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding=  FragmentDateBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        date_picker = new DatePicker(this);
        resultado = root.findViewById(R.id.btn_date);
        resultado.setOnClickListener(this);

        if (MainActivity.FECHA == null){
            date_picker.obtenerFecha();
        }
        return root;
    }


    @Override
    public void onClick(View view) {
        date_picker.obtenerFecha();
    }
    @Override
    public void onResultadoFecha(GregorianCalendar fecha) {
        MainActivity.FECHA = fecha.get(Calendar.DAY_OF_MONTH)+"/"+(fecha.get(Calendar.MONTH)+1)+"/"+fecha.get(Calendar.YEAR);
    }
}