package com.example.tarea3_zb_carlos;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.Activity;
import android.os.Bundle;

import com.example.tarea3_zb_carlos.databinding.ActivityMainBinding;
import com.example.tarea3_zb_carlos.fragments.bikes.bikesFragment;
import com.example.tarea3_zb_carlos.fragments.bikes.recycler_view.MyAdapter;
import com.example.tarea3_zb_carlos.fragments.date.dateFragment;
import com.example.tarea3_zb_carlos.fragments.home.homeFragment;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    public static String FECHA = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ReplaceFragment(new homeFragment());

        binding.bottomNavigationView.setOnItemSelectedListener(item ->{
            switch (item.getItemId()){
                case R.id.home:
                    ReplaceFragment(new homeFragment());
                    break;
                case R.id.profile:
                    ReplaceFragment(new dateFragment());
                    break;
                case R.id.settings:
                    ReplaceFragment(new bikesFragment());
                    break;
            }

            return true;
        });
    }




    private void ReplaceFragment(Fragment fragment){
        FragmentManager fragment_manager = getSupportFragmentManager();
        FragmentTransaction fragment_transaction = fragment_manager.beginTransaction();
        fragment_transaction.replace(R.id.frameLayout, fragment);
        fragment_transaction.commit();
    }
}