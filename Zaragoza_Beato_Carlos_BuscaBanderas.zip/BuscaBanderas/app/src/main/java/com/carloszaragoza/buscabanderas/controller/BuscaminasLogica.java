package com.carloszaragoza.buscabanderas.controller;

import android.graphics.Color;
import android.view.View;
import android.widget.GridLayout;

import com.carloszaragoza.buscabanderas.model.Casilla;

public class BuscaminasLogica {


    /**
     * Mettodo que inserta un determinado numero de minas en nuestro tablero aleatoriamente.
     * @param minas
     * @param tablero
     */
    public void insertar_minas(int minas, int[][] tablero) {
        boolean minaFila = false;
        while (minas > 0) {
            for (int i = 0; i < tablero.length; i++) {
                minaFila = true;
                for (int j = 0; j < tablero[i].length; j++) {
                    int x = (int) (Math.random() * tablero.length);
                    if (minaFila && minas > 0) {
                        tablero[i][x] = -1;
                        minas--;
                    }
                    minaFila = false;
                }
            }
        }
    }


    /**
     * Metodo que comprueba las cercanias de cada cuadrado teniendo cuidado con los limites de nuestro tablero,
     * Una vez comprueba las cercanias, introduce el valor de las minas cercanas en nuestro tablero.
     * @param rows
     * @param columns
     * @param board
     */
    public void comprobar_tablero(int rows, int columns, int[][] board) {
        int acumulador = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (board[i][j] != -1) {
                    acumulador = 0;
                    for (int x_siguiente = i - 1; x_siguiente <= i + 1; x_siguiente++) {
                        if (x_siguiente >= 0 && x_siguiente < rows) {
                            for (int y_siguiente = j - 1; y_siguiente <= j + 1; y_siguiente++) {
                                if (y_siguiente >= 0 && y_siguiente < columns && board[x_siguiente][y_siguiente] == -1) {
                                        acumulador++;
                                }
                            }
                        }
                    }
                    board[i][j] = acumulador;
                }
            }
        }
    }

    /**
     * metodo que comprueba si la casilla que se le pasa por parametro es un cero, y si es un cero que
     * la pinte roja, y que comprueba la casilla siguiente y si es un cero la vuelva pinta de color rojo, todo
     * esto llamado recursivamente con el metodo callOnClick que vuelve a llamar al metodo on click.
     * @param casilla
     * @param grid
     * @param columns
     * @param rows
     */
    public void mostrar_tablero(Casilla casilla, GridLayout grid, int columns, int rows) {
        if(casilla.value == 0){
            View ficha = grid.getChildAt((rows * casilla.x) + casilla.y);
            ficha.setBackgroundColor(Color.rgb(252, 50, 50));
            for (int i = casilla.x - 1; i <= casilla.x + 1; i++) {
                if (i >= 0 && i < rows) {
                    for (int j = casilla.y - 1; j <= casilla.y + 1; j++) {
                        if (j >= 0 && j < columns) {
                            grid.getChildAt((rows * i) + j).callOnClick();
                        }
                    }
                }
            }
        }
    }
}
