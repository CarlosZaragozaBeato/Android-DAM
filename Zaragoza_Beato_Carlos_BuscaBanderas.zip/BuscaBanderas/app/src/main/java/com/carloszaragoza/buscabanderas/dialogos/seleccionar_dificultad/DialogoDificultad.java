package com.carloszaragoza.buscabanderas.dialogos.seleccionar_dificultad;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import com.carloszaragoza.buscabanderas.Buscabanderas;
import com.carloszaragoza.buscabanderas.R;

public class DialogoDificultad extends DialogFragment {

    DialogoDificultadInterface dlg;


    public interface DialogoDificultadInterface{
        void seleccionarDificultad(int level);
    }


    @Override
    public void onAttach(Context context) {
        dlg = (DialogoDificultadInterface) context;
        super.onAttach(context);
    }



    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Seleccionar Configurar");
        Buscabanderas bcb = (Buscabanderas) getActivity();
        builder.setTitle("Configurar Dificultad");
        builder.setSingleChoiceItems(R.array.niveles, bcb.nivel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DialogoDificultad.this.dlg.seleccionarDificultad(i);
            }
        });
        builder.setPositiveButton("Ok", null);
        return builder.create();
    }





}
