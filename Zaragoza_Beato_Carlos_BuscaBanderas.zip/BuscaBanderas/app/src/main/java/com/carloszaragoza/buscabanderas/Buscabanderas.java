package com.carloszaragoza.buscabanderas;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.carloszaragoza.buscabanderas.controller.BuscaminasLogica;
import com.carloszaragoza.buscabanderas.dialogos.cambiar_jugador.DialogoPersonaje;
import com.carloszaragoza.buscabanderas.dialogos.seleccionar_dificultad.DialogoDificultad;
import com.carloszaragoza.buscabanderas.model.Casilla;

public class Buscabanderas extends AppCompatActivity implements View.OnClickListener,
        View.OnLongClickListener,
        DialogoDificultad.DialogoDificultadInterface,
        DialogoPersonaje.cambiarPersonajeInterface {
    public GridLayout grid;
    public int [][] tablero;
    private Menu menu;
    public int nivel = 0;
    public int jugador = 0;
    public int fila = 8;
    public int columna = 8;
    public int mina = 10;
    public int contador_minas = 10;
    public boolean end = false;
    public boolean win = false;

    private BuscaminasLogica logica = new BuscaminasLogica();


    /**
     * Metodo que desplega un dialogo que muestra las instrucciones
     */
    public void mostrar_instrucciones() {
        AlertDialog.Builder dialogo = new AlertDialog.Builder(this);
        dialogo.setTitle("Instrucciones");
        dialogo.setMessage(R.string.description);
        dialogo.setPositiveButton(R.string.ok, null);
        dialogo.show();
    }

    /**
     * Metodo que crea un objeto de la clase Dialogo Dificulta y muestra el dialogo
     */
    public void configurar_dialogo(){
        DialogoDificultad dlg = new DialogoDificultad();
        dlg.show(getFragmentManager(), "Diálogo de configuración");
        comenzar_juego();}

    /**
     * Metodo que pone en false el final del juego y llama al metodo de seleccionar la dificultad
     * este metodo inicializa el juego con la dificultad indicada.
     */
    public void comenzar_juego(){
        this.end = false;
        seleccionarDificultad(this.nivel);
    }

    /**
     * Metodo que crea un objeto de la clase DialogoPersonaje
     * y muestra el dialogo
     */
    public void cambiar_personaje(){

        DialogoPersonaje dialogo = new DialogoPersonaje();
        dialogo.show(getFragmentManager(), "Seleccion Personaje");
        comenzar_juego();
    }

    /**
     * En este metodo inicializamos el juego
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscabanderas);
        seleccionarDificultad(this.nivel);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        switch(id){
            case R.id.mnInstrucciones:
                mostrar_instrucciones();
                break;
            case R.id.mnComenzar:
                comenzar_juego();
                break;
            case R.id.mnConfigurar:
                configurar_dialogo();
                break;
            case R.id.mnPlayer:
                cambiar_personaje();
                break;
        }
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_banderas, menu);
        this.menu = menu;
        return true;
    }


    /**
     * Metodo el cual mediante un int que le pasamos por parametro del dialogo de seleccion de dificultad
     * le indicamos el total de filas, columnas y minas, creamos y rellenamos el tablero.
     * @param level
     */
    @Override
    public void seleccionarDificultad(int level) {
            switch(level){
                case 0:
                    this.fila = 8;
                    this.columna = 8;
                    this.mina = 8;
                    break;
                case 1:
                    this.fila = 12;
                    this.columna = 12;
                    this.mina = 30;
                    break;
                case 2:
                    this.fila = 16;
                    this.columna = 16;
                    this.mina = 60;
                    break;

            }
        this.nivel = level;
            crear_tablero(this.fila,this.columna, this.mina);
            rellenar_tablero(this.fila,this.columna, this.mina);

            this.contador_minas = this.mina;
    }



    @Override
    public void cambiarPersonaje(int player) {
        this.jugador = player;
        this.menu.getItem(0).setIcon(elegir_icono(player));
        rellenar_tablero(this.fila,this.columna, this.mina);
    }

    /**
     * Metodo que se le pasa una posicion del personaje indicado en el dialogo y devuelve una bandera
     * @param posicion
     * @return
     */
    public int elegir_icono(int posicion) {
        switch (posicion) {
            case 0:
                return R.drawable.alemania;
            case 1:
                return R.drawable.argentina;
            case 2:
                return R.drawable.brasil;
            case 3:
                return R.drawable.chile;
            case 4:
                return R.drawable.colombia;
            case 5:
                return R.drawable.croacia;
            case 6:
                return R.drawable.estados_unidos;
            case 7:
                return R.drawable.francia;
            case 8:
                return R.drawable.japon;
            default:
                return R.drawable.espana;
        }
    }


    @SuppressLint("UseCompatLoadingForDrawables")
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    public void rellenar_tablero(int rows, int columns, int mines) {
        this.grid = new GridLayout(getApplicationContext());
        ConstraintLayout layout = findViewById(R.id.layout_principal);
        this.contador_minas = mines;
        GridLayout.LayoutParams param = new GridLayout.LayoutParams();
        param.setMargins(0, 0, 0, 0);
        param.height = -1;
        param.width = -1;
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x - 100;
        int height = size.y - 350;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(width / columns, height / rows);
        layoutParams.setMargins(0, 0, 0, 0);
        this.grid.setRowCount(rows);
        this.grid.setColumnCount(columns);
        this.grid.setLayoutParams(param);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (this.tablero[i][j] == -1) {
                    ImageButton b = new ImageButton(this);
                    b.setBackground(getResources().getDrawable(R.drawable.formaboton));
                    b.setLayoutParams(layoutParams);
                    b.setTag(new Casilla(i, j, this.tablero[i][j]));
                    b.setId(View.generateViewId());
                    b.setOnClickListener(this);
                    b.setOnLongClickListener(this);
                    this.grid.addView(b);
                } else {
                    Button b2 = new Button(this);
                    b2.setBackground(getResources().getDrawable(R.drawable.formaboton));
                    b2.setTag(new Casilla(i, j, this.tablero[i][j]));
                    b2.setLayoutParams(layoutParams);
                    b2.setId(View.generateViewId());
                    b2.setOnClickListener(this);
                    b2.setOnLongClickListener(this);
                    this.grid.addView(b2);
                }
            }
        }
        layout.removeAllViews();
        layout.addView(this.grid);
        this.mina = mines;
    }

    /**
     * Este metodo crea el tablero segun los parametros que le pasemos.
     * inserta las minas, y comprueba las cercanias de cada mina.
     * @param rows
     * @param columns
     * @param mines
     */
    private void crear_tablero(int rows, int columns, int mines) {
        this.tablero = new int[rows][columns];
        logica.insertar_minas(mines, this.tablero);
        logica.comprobar_tablero(this.fila, this.columna, this.tablero);
    }


    @Override
    public void onClick(View view) {
        view.setOnLongClickListener(null);
        view.setOnClickListener(null);
        if (this.end) {
            if (this.win) {
                Toast.makeText(getApplicationContext(), (int) R.string.win, Toast.LENGTH_LONG).show();
                return;
            } else {
                Toast.makeText(getApplicationContext(), (int) R.string.lose, Toast.LENGTH_LONG).show();
                return;
            }
        }
        Casilla csl = (Casilla) view.getTag();
        if (csl.value == -1) {
            ImageButton ib = (ImageButton) view;
            ib.setImageDrawable(getResources().getDrawable(elegir_icono(this.jugador)));
            ib.setScaleType(ImageView.ScaleType.FIT_XY);
            this.end = true;
            Toast.makeText(getApplicationContext(), R.string.lose, Toast.LENGTH_LONG).show();

        } else if(csl.value!=0){
            Button b = (Button) view;
            b.setText(csl.value +"");
        }
        logica.mostrar_tablero(csl, this.grid, this.fila, this.columna);
    }

    @SuppressLint({"UseCompatLoadingForDrawables", "SetTextI18n"})
    @Override
    public boolean onLongClick(View view) {
        view.setOnLongClickListener(null);
        view.setOnClickListener(null);
        Casilla csl = (Casilla) view.getTag();
        if (csl.value == -1) {
            ImageButton ib = (ImageButton) view;
            ib.setImageDrawable(getResources().getDrawable(elegir_icono(this.jugador)));
            ib.setScaleType(ImageView.ScaleType.FIT_XY);
            this.contador_minas--;
            if (this.contador_minas == 0) {
                this.end = true;
                this.win = true;
                Toast.makeText(getApplicationContext(),R.string.win, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.good) + ", te quedan " + this.contador_minas, Toast.LENGTH_LONG).show();
            }
        } else {
            Button b = (Button) view;
            b.setText(csl.value +"");
            Toast.makeText(getApplicationContext(),R.string.lose_mine, Toast.LENGTH_LONG).show();
            this.end = true;
            this.win = false;
        }
        return true;
    }
}