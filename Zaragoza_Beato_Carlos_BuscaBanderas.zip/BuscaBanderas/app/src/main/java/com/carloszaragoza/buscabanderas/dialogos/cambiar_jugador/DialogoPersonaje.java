package com.carloszaragoza.buscabanderas.dialogos.cambiar_jugador;


import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.carloszaragoza.buscabanderas.R;

public class DialogoPersonaje extends DialogFragment {
    cambiarPersonajeInterface dlg;
    int [] imagenes = {
            R.drawable.alemania,
            R.drawable.argentina,
            R.drawable.brasil,
            R.drawable.chile,
            R.drawable.colombia,
            R.drawable.croacia,
            R.drawable.estados_unidos,
            R.drawable.francia,
            R.drawable.japon,
            R.drawable.espana};

    String[] nombre;

    public interface cambiarPersonajeInterface{
         void cambiarPersonaje(int player);
    }


    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        this.nombre = getActivity().getResources().getStringArray(R.array.banderas);
        AlertDialog.Builder dialogo = new AlertDialog.Builder(getActivity());
        LayoutInflater layout = getActivity().getLayoutInflater();
        View FilaPersonaje = layout.inflate(R.layout.jugador,null);
        Spinner seleccion = FilaPersonaje.findViewById(R.id.spinnerJugador);
        seleccion.setAdapter(new SelectorAdapter(getActivity(), R.layout.fila_jugador, this.nombre));
        dialogo.setView(FilaPersonaje);
        dialogo.setPositiveButton("Ok", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                DialogoPersonaje.this.dlg.cambiarPersonaje(seleccion.getSelectedItemPosition());
            }
        });
        return dialogo.create();
    }

    @Override
    public void onAttach(Context context) {
        this.dlg = (cambiarPersonajeInterface) context;
        super.onAttach(context);
    }

    public class SelectorAdapter extends ArrayAdapter<String>{

        public SelectorAdapter(Context context, int resource, String[] objects) {
            super(context, resource, objects);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent){
            return FilaPersonaje(position, convertView, parent);
        }
        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent){
            return FilaPersonaje(position, convertView, parent);
        }
        public View FilaPersonaje(int position, View convertView, ViewGroup parent){
            LayoutInflater inflater = DialogoPersonaje.this.getActivity().getLayoutInflater();
            View fila = inflater.inflate(R.layout.fila_jugador, parent, false);
            TextView name = fila.findViewById(R.id.tvNombre);
            name.setText(DialogoPersonaje.this.nombre[position]);
            ImageView imagen = fila.findViewById(R.id.ivPlayer);
            imagen.setImageResource(DialogoPersonaje.this.imagenes[position]);
            return fila;
        }

    }
}
