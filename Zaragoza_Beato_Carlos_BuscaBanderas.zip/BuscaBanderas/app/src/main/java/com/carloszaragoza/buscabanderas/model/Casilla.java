package com.carloszaragoza.buscabanderas.model;


public class Casilla {
    public int x;
    public int y;
    public int value;

    public Casilla(int x, int y, int v) {
        this.x = x;
        this.y = y;
        this.value = v;
    }
}
